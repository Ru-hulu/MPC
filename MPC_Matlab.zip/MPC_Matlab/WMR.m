function [now_x,now_y,now_yaw] =WMR(u_v,u_w,pre_x,pre_y,pre_yaw)
    dlta_T=0.1;
    now_x = pre_x+u_v*cos(pre_yaw)*dlta_T;
    now_y = pre_y+u_v*sin(pre_yaw)*dlta_T;
    now_yaw = pre_yaw + dlta_T*u_w;
end