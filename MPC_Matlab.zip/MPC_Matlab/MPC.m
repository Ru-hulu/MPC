function [now_u1,now_u2] = MPC(now_x,now_y,now_yaw,pre_u1,pre_u2,ref_x,ref_y,ref_yaw,ref_w,ref_v)%输入当前状态，轨迹中的参考状态,上一时刻的控制量，得到当前的控制量
    Nc=30;%控制时域
    Np=60;%预测时域
    L=0.4;%轴距为40cm
    Nx = 3;%状态量个数
    Nu = 2;%控制量个数
    Tsim = 20;%仿真时间
    N=100; T=0.05;%参考轨迹点数量和采样周期
    X0=[0,8,0];%车辆初始状态在y轴上
    Xout = zeros(N,3);%参考轨迹长度 有100个点
    v_ref = 0.1;
    x_ref = [ref_x,ref_y,ref_yaw];
    x_now = [now_x,now_y,now_yaw];%X(k)此刻真实状态
    u_pre = [pre_u1,pre_u2];%u(k-1)
    U = [0.01,0.01];%是上一时刻的~u(k-1)= u(k-1)-u_ref(k-1)
    for k=1:1:N
        Xout(k,1)=k*T;
        Xout(k,2)=2;
        Xout(k,3)=0;
    end
    %参考轨迹是y=2一条直线。
    
    a=[1,0,-T*v_ref*sin(ref_yaw);
       0,1, T*v_ref*cos(ref_yaw);
       0,0, 1];
    b=[T*sin(ref_yaw),0;
       T*cos(ref_yaw),0;
       0,T];
    %先计算出离散化的a,b。这两个矩阵的数值会随着时间k变化
    A=[a,b;zeros(2,3),eye(2,2)];%这里刚好是5*5的矩阵
    B=[b;eye(2,2)];%尺寸5*2
    C=[eye(3,3),zeros(3,2);
       zeros(2,3),zeros(2,2)];
    Fai_cell=cell(Np,1);
    Xita_cell = cell(Np,Nc);
    for i=1:1:Np
        Fai_cell{i,1}=C*A^i;
    end
    for i=1:1:Np%行
        for j=1:1:Nc%列
            if j<=i
                Xita_cell{i,j}=C*A^(i-j)*B;
            else
                Xita_cell{i,j}=zeros(3,2);
            end
        end
    end

    Fai = cell2mat(Fai_cell);%Fai的尺寸为Nx*Np,(Nx+Nu)
    Xita = cell2mat(Xita_cell);%Xita的尺寸为Np*Nx,Nc*Nu
    Q=100*eye(Np*Nx,Np*Nx);
    R=1*eye(Nc*Nu,Nc*Nu);
    H_cell=cell{2,2};
    H_cell{1,1}=Xita'*Q*Xita+R;
    H_cell{2,2}=20;%松弛因子
    H_cell{2,1}=zeros(Nc*Nu,1);
    H_cell{1,2}=zeros(1,Nc*Nu);
    H = cell2mat(H_cell);%% [Nc*Nu+1,Nc*Nu+1]
    umin = [-0.2;-0.54];%控制量约束
    umax = [0.2;0.332];
    delta_umin=[-0.05;-0.64];%控制量变化约束
    delta_umax=[0.05,0.64];

    kexi = zeros(Nx+Nu,1);
    kexi(1:Nx)=x_now-x_ref;
    kexi(Nx+1:Nx+Nu) = U;%%本来应该是U(k-1)-U_ref(k-1)这里和数学上不一致,不是很理解U_ref应该怎么获得
    E = Fai*kexi;%[Nx*Np,1]
    g_cell = cell(1,2);
    g_cell{1,1} = E'*Q*Xita;
    g_cell{1,2} = 0;%%要和H行数相同，松弛因子
    g = cell2mat(g_cell);
    for i = 1:1:Nc
        A_i(i,1:i)=1;
    end
    A_I = kron(A_i,eye(Nu));
    Ut = kron(ones(Nc,1),U);
    Umin = kron(ones(Nc,1),umin);
    Umax = kron(ones(Nc,1),umax);
    delta_Umin = kron(ones(Nc,1),delta_umin);
    delta_Umax = kron(ones(Nc,1),delta_umax);
    A_cons_cell={A_I,zeros(Nu*Nc,1);
                -A_I,zeros(Nu*Nc,1)};
    A_cons = cell2mat(A_cons_cell);% (Nu*Nc*2,1)
    b_cons_cell = {Umax-Ut;-Umin+Ut};
    b_cons =cell2mat(b_cons_cell);
    lb = [delta_Umin;0];
    ub = [delta_Umax;1];
    options = optimoptions('quadprog','Display','iter','MaxIterations',100,'TolFun',1e-16);
    delta_U = quadprog(H,g,A_cons,b_cons,[],[],lb,ub,[],options);%[Nu*Nc+1,1]包含了松弛因子

    delta_v_tilde = delta_U(1);
    delta_Delta_tilde = delta_U(1);
    
    U_now(1) = kexi(4)+delta_v_tilde;
    U_now(2) = kexi(5)+delta_Delta_tilde;

    v_real = U_now(1)+v_ref;
    Delta_real = U_now(2)+Delta_r;%%%%疑问：V——reference 和W_reference怎么获得？

end