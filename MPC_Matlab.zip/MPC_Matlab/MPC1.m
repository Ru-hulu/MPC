function [now_u1,now_u2] = MPC1(now_x,now_y,now_yaw,ref_x,ref_y,ref_yaw,ref_v,ref_w)%输入当前状态，轨迹中的参考状态,上一时刻的控制量，得到当前的控制量
    Np=8;%预测时域
    Nx = 3;%状态量个数
    Nu = 2;%控制量个数
    x_ref = ref_x(1,1);
    y_ref = ref_y(1,1);    
    yaw_ref = ref_yaw(1,1);
    v_ref = ref_v(1,1);
    u_max = [3,2]';
    u_min = [-3,-2]';
    Ur_cell=cell(Np,1);
    for j=1:1:Np
        Ur_cell{j,1}=[ref_v(j,1),ref_w(j,1)]';
    end    
    Ur = cell2mat(Ur_cell);
    Ur(Nu*Np+1,1)=0;%此处为松弛因子
    T=0.1;%参考轨迹点数量和采样周期
    x_bo =[now_x-x_ref,now_y-y_ref,now_yaw-yaw_ref]';
    a_k=[1,0,-T*v_ref*sin(yaw_ref);
         0,1, T*v_ref*cos(yaw_ref);
         0,0, 1];
    b_k=[T*cos(yaw_ref),0;
         T*sin(yaw_ref),0;
         0,T];
    A_hatcell = cell(Np,1);

    for i=1:1:Np
        A_hatcell{i,1} = a_k^i;
    end
    A_hat = cell2mat(A_hatcell);
    B_hatcell = cell(Np,Np);
    for i=1:1:Np
    for j=1:1:Np
            if j<=i
                B_hatcell{i,j}=a_k^(i-j)*b_k;
            else
                B_hatcell{i,j}=zeros(Nx,Nu);
            end
    end
    end
    B_hat = cell2mat(B_hatcell);
    q=diag([1,1,1]);
    r=diag([1,1]);
    Q = kron(eye(Np),q);
    R = kron(eye(Np),r);
    H_ori = (B_hat'*Q*B_hat+R);
    g_ori = x_bo'*A_hat'*Q*B_hat;
    H = [H_ori,zeros(Np*Nu,1);
         zeros(1,Np*Nu),1];
    H =  0.5*(H'+H);
    g = [g_ori,0];
    Umax = kron(ones(Np,1),u_max); 
    Umin = kron(ones(Np,1),u_min); 
    u_ub = [Umax;1];
    u_lb = [Umin;0];
    ub = u_ub-Ur;
    lb = u_lb-Ur;
    A_quadprog = [eye(Np*Nu+1);zeros(Np*Nu+1,Np*Nu+1)-eye(Np*Nu+1)];
    b_quadprog = [u_ub-Ur;-u_lb+Ur];
    options = optimoptions('quadprog','Display','iter','MaxIterations',100,'TolFun',1e-16);
    delta_U = quadprog(H,g',A_quadprog,b_quadprog,[],[],lb,ub,[],options);%[Nu*Nc+1,1]包含了松弛因子
    now_u1 = delta_U(1,1)+Ur(1,1);
    now_u2 = delta_U(2,1)+Ur(2,1);
    t = 0;
end