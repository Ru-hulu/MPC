clc;
clear;
Sim_T = 80;%仿真时间20s
delta_t = 0.1;
length_trajectory = Sim_T/delta_t;
[ref_x,ref_y,ref_yaw,ref_v,ref_w]=GeneratePath(length_trajectory);
sta_car_now =[0,6.5,0]; 
figure; 

for ti =1:1:length_trajectory
    ref_x_in = ref_x(ti:(ti+4),1);
    ref_y_in = ref_y(ti:(ti+4),1);
    ref_yaw_in = ref_yaw(ti:(ti+4),1);
    ref_v_in = ref_v(ti:(ti+4),1);
    ref_w_in = ref_w(ti:(ti+4),1);
    
    % [u_v,u_w]  = MPC2(sta_car_now(1,1),sta_car_now(1,2),sta_car_now(1,3),ref_x_in,ref_y_in,ref_yaw_in,ref_v_in,ref_w_in);
   [u_v,u_w]  = MPC2(sta_car_now(1,1),sta_car_now(1,2),sta_car_now(1,3),ref_x_in,ref_y_in,ref_yaw_in,ref_v_in,ref_w_in);
    [sta_car_now(1,1),sta_car_now(1,2),sta_car_now(1,3)] = WMR(u_v,u_w,sta_car_now(1,1),sta_car_now(1,2),sta_car_now(1,3));
    plot(sta_car_now(1,1),sta_car_now(1,2),'o','MarkerEdgeColor',[0.50,0.2,0.1],'MarkerFaceColor',[0.1,0.8,0.3]);
    plot(ref_x(ti,1),ref_y(ti,1),'o','MarkerEdgeColor',[0.50,0.5,0.1],'MarkerFaceColor',[0.7,0.5,0.1]);
    hold on 
end