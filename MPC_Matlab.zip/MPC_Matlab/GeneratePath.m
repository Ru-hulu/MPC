function [ref_x,ref_y,ref_yaw,ref_v,ref_w] = GeneratePath(length_of_path)
    ref_x = zeros(1,length_of_path+4)';
    ref_y = zeros(1,length_of_path+4)';
    ref_yaw = zeros(1,length_of_path+4)';
    ref_v = zeros(1,length_of_path+4)';
    ref_w = zeros(1,length_of_path+4)';
    R = 6;
    delta_T= 0.1;
    delta_xita = 2*pi/length_of_path;
    for i = 1:1:(length_of_path+4)
        this_xita = pi/2-delta_xita*i;
        ref_x(i,1)=R*cos(this_xita);
        ref_y(i,1)=R*sin(this_xita);
        ref_yaw(i,1)=this_xita-pi/2;
        ref_v(i,1)=2*pi*R/(length_of_path*delta_T);%2.51
        ref_w(i,1)=2*pi/(length_of_path*delta_T);%0.314
    end
    % for i = 1:1:length_of_path+4
    %     ref_x(i,1)=i*0.05*0.5;
    %     ref_y(i,1)=6;
    %     ref_yaw(i,1)=0;
    %     ref_v(i,1)=0.5;%2.51
    %     ref_w(i,1)=0;%0.314
    % end
        
end
%生成以0 0 为圆心，8为半径的圆形轨迹。