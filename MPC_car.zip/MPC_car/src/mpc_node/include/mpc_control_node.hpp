#include<ros/ros.h>
#include<unistd.h>
#include<iostream>
#include<stdlib.h>
#include <gazebo_msgs/GetModelState.h>
#include <gazebo_msgs/SetModelState.h>
#include<visualization_msgs/MarkerArray.h>
#include<visualization_msgs/Marker.h>
#include<utility>
#include<cmath>
#include<algorithm>
#include "Eigen/Core"
#include"qpOASES.hpp"
#include<vector>
class MPC_Control
{
    public:
        MPC_Control(ros::NodeHandle &n,int Np_,int Nc_,float delta_t_, float sim_Time_);
        void GeneratePathSimulate();
        bool ShowCar();
        void UpdateCarState(double cont_u, double cont_w);
        std::pair<double,double> MPC_Solve();
        ros::NodeHandle nh;
        ros::ServiceServer RoutServer;
        ros::ServiceClient  SetCarvw;
        ros::ServiceClient GetCarstate;        
        ros::Publisher CarPub;
        int path_len;
        std::vector<double>his_pathx;
        std::vector<double>his_pathy;
        Eigen::Matrix<float,3,1> now_carstate{0.0,0.0,0.0};//当前车的状态

    private:
        float delta_t=0.1;
        float sim_Time = 80;//仿真时间80s
        float max_v=3;
        float min_v=-3;
        float max_w=2;
        float min_w=-2;
        int path_track_counter;//当前已经追踪到了轨迹中哪一个点上。
        std::vector<double> ref_x;
        std::vector<double> ref_y;
        std::vector<double> ref_yaw;
        std::vector<double> ref_v;
        std::vector<double> ref_w;
        int Np=5;//预测时长
        int Nc=4;//控制时域
        int Nx=3;//状态量个数
        int Nu=2;//控制量个数
        Eigen::Matrix<float, 3,1>x_bo{0.0,0.0,0.0};
        Eigen::MatrixXf U_max;
        Eigen::MatrixXf U_min;
        // Eigen::MatrixXf Ur;//(Nc*Nu+1,1)
        Eigen::MatrixXf A_qua;
};