#include"mpc_control_node.hpp"
MPC_Control::MPC_Control(ros::NodeHandle &n,int Np_,int Nc_,float delta_t_, float sim_Time_):nh(n)
{
    Np = Np_;
    Nc = Nc_;
    delta_t = delta_t_;
    sim_Time = sim_Time_;
    path_len = sim_Time/delta_t;
    // Ur.resize(Nc*Nu+1,1);
    A_qua.resize(2*(Nu*Nc+1),(Nu*Nc+1));
    // A_qua.block<Nu*Nc+1,Nu*Nc+1>(0,0) = 
    A_qua.block<2*4+1,2*4+1>(0,0) = Eigen::MatrixXf::Identity(2*4+1,2*4+1);
    A_qua.block<2*4+1,2*4+1>(2*4+1,0) = Eigen::MatrixXf::Zero(2*4+1,2*4+1)-Eigen::MatrixXf::Identity(2*4+1,2*4+1);
    U_max.resize(Nu*Nc+1,1);//带上松弛因子
    U_min.resize(Nu*Nc+1,1);//带上松弛因子
    for(int i =0;i<Nu*Nc;i++)
    {
        if(i%2==0)//赋值速度
        {
            U_max(i,0)=max_v;
            U_min(i,0)=min_v;
        }
        else//奇数赋值角速度
        {
            U_max(i,0)=max_w;
            U_min(i,0)=min_w;
        }
    }
    U_max(Nu*Nc,0)=1;
    U_min(Nu*Nc,0)=0;
    GeneratePathSimulate();
    path_track_counter=0;
    now_carstate<<-3.0,6.0,0.0;
    CarPub = nh.advertise<visualization_msgs::MarkerArray>("car_array",10);
    std::cout<<"After Initial, the length of track is "<<path_len<<" Initial pose is "<<now_carstate<<" delta_t is "<<delta_t<<std::endl;
}

void MPC_Control::UpdateCarState(double cont_v, double cont_w)
{
    //仿真系统，更新车的状态信息。
    double now_x=now_carstate(0,0);
    double now_y=now_carstate(1,0);
    double now_yaw=now_carstate(2,0);
    double new_x = now_x+cont_v*delta_t*std::cos(now_yaw);
    double new_y = now_y+cont_v*delta_t*std::sin(now_yaw);
    double new_yaw = now_yaw+cont_w*delta_t;
    now_carstate(0,0)=new_x;
    now_carstate(1,0)=new_y;
    now_carstate(2,0)=new_yaw;
    std::cout<<"In "<<path_track_counter<<" CarState is "<<new_x<<" "<<new_y<<" "<<new_yaw<<std::endl;    
}
void MPC_Control::GeneratePathSimulate()
{
    ref_x.clear();
    ref_y.clear();
    ref_yaw.clear();
    ref_v.clear();
    ref_w.clear();

    float R = 6;
    float delta_xita = 2*M_PI/path_len;
    float d_this=0;
    for(int i=1;i<=path_len+Np-1;i++)
    {
        float this_xita = M_PI_2-delta_xita*i;
        d_this = R*cos(this_xita);
        ref_x.push_back(d_this);
        d_this = R*sin(this_xita);
        ref_y.push_back(d_this);
        d_this = this_xita-M_PI_2;
        ref_yaw.push_back(d_this);
        d_this = 2*M_PI*R/(path_len*delta_t);
        ref_v.push_back(d_this);
        d_this = 2*M_PI/(path_len*delta_t);
        ref_w.push_back(d_this);
    }
}
bool MPC_Control::ShowCar()
{
    visualization_msgs::MarkerArray carCubes;
    visualization_msgs::Marker carCube;
    carCube.ns = "basic_shapes";
    carCubes.markers.clear();
    for(int i =0;i<path_len;i++)
    {
            carCube.header.frame_id = "map";
            carCube.header.stamp = ros::Time::now();
            carCube.id = i;
            carCube.type = visualization_msgs::Marker::CUBE;
            carCube.scale.x = 0.1;
            carCube.scale.y =0.1;
            carCube.scale.z =0.1;
            carCube.color.a = 1;
            carCube.color.r = 255;
            carCube.color.g = 255;
            carCube.color.b = 0;
            carCube.pose.position.x = his_pathx[i];
            carCube.pose.position.y = his_pathy[i];
            carCubes.markers.push_back(carCube);        
    }
    for(int i =path_len;i<2*path_len;i++)
    {
            carCube.header.frame_id = "map";
            carCube.header.stamp = ros::Time::now();
            carCube.id = i;
            carCube.type = visualization_msgs::Marker::CUBE;
            carCube.scale.x = 0.1;
            carCube.scale.y =0.1;
            carCube.scale.z =0.1;
            carCube.color.a = 1;
            carCube.color.r = 0;
            carCube.color.g = 255;
            carCube.color.b = 255;
            carCube.pose.position.x = ref_x[i-path_len];
            carCube.pose.position.y = ref_y[i-path_len];
            carCubes.markers.push_back(carCube);        
    }
    CarPub.publish(carCubes);
}
std::pair<double,double> MPC_Control::MPC_Solve()
{
    float now_ref_x=ref_x[path_track_counter];
    float now_ref_y=ref_y[path_track_counter];
    float now_ref_yaw=ref_yaw[path_track_counter];
    float now_ref_v=ref_v[path_track_counter];
    Eigen::Matrix<float,3,1>  now_state_ref;
    now_state_ref<<now_ref_x,now_ref_y,now_ref_yaw;

    std::cout<<"In "<<path_track_counter<<" Step, the ref pos is "<<now_ref_x<<" "<<now_ref_y<<" "<<now_ref_yaw<<std::endl;
    Eigen::Matrix3f a;
    a<< 1,0,(0-delta_t*now_ref_v*std::sin(now_ref_yaw)),
             0,1,(delta_t*now_ref_v*std::cos(now_ref_yaw)),
             0,0,1;
    std::cout<<a<<std::endl;             
    Eigen::Matrix<float, 3,2> b;
    b<< (delta_t*std::cos(now_ref_yaw)),0,
             (delta_t*std::sin(now_ref_yaw)),0,
             0,delta_t;
    std::cout<<b<<std::endl;             
    x_bo = now_carstate-now_state_ref;
    Eigen::MatrixXf A_hat(Np*Nx,Nx);
    Eigen::Matrix3f A_temp; A_temp = a;
    Eigen::MatrixXf B_hat(Np*Nx,Nc*Nu);
    Eigen::MatrixXf zerob=Eigen::MatrixXf::Zero(Nx,Nu);
    for(int i =0;i<Np;i++)
    {
        A_hat.block<3,3>(i*Nx,0)=A_temp;
        A_temp = A_temp*a;
    }
    for(int i =0;i<Np;i++)
    for(int j=0;j<Nc;j++)
    {
        if(i==j)
            B_hat.block<3,2>(i*Nx,j*Nu) = b;
        if(j<i)
            B_hat.block<3,2>(i*Nx,j*Nu) = A_hat.block<3,3>((i-j-1)*Nx,0)*b;
        else
            B_hat.block<3,2>(i*Nx,j*Nu) = zerob;
    }
    Eigen::MatrixXf Q=Eigen::MatrixXf::Zero(Np*Nx,Np*Nx);
    for(int i =0;i<Np*Nx;i++)Q(i,i)=1.0;
    Eigen::MatrixXf R=Eigen::MatrixXf::Zero(Nc*Nu,Nc*Nu);
    for(int i =0;i<Nc*Nu;i++)R(i,i)=0.001;
    Eigen::MatrixXf H=Eigen::MatrixXf::Zero(Nc*Nu+1,Nc*Nu+1);
    // H.block<Nc*Nu,Nc*Nu>(0,0)=B_hat.transpose()*Q*B_hat+R;
    H.block<4*2,4*2>(0,0)=B_hat.transpose()*Q*B_hat+R;
    H(Nc*Nu,Nc*Nu)=1;//松弛因子
    std::cout<<H<<std::endl;
    Eigen::MatrixXf f=Eigen::MatrixXf::Zero(1,Nc*Nu+1);
    // f.block<1,Nc*Nu>(0,0)
    f.block<1,4*2>(0,0)=x_bo.transpose()*A_hat.transpose()*Q*B_hat;
    f(0,Nc*Nu)=1;//松弛因子
    Eigen::MatrixXf b_qua(2*(Nc*Nu+1),1);
    Eigen::MatrixXf Ur(Nc*Nu+1,1);
    for(int i=0;i<Nc*Nu;i++)
    {
        Ur(i,0)=ref_v[int(i/2)+path_track_counter];
        i++;
        Ur(i,0)=ref_w[int(i/2)+path_track_counter];
    }//拿到两个参考控制量
    Ur(Nc*Nu,0)=0;//松弛因子
    Eigen::MatrixXf ub = U_max-Ur;
    Eigen::MatrixXf lb = U_min-Ur;//拿到优化变量的上界下界

    b_qua.block<4*2+1,1>(0,0)=U_max-Ur;
    b_qua.block<4*2+1,1>(4*2+1,0)=Ur-U_min;
    std::cout<<b_qua<<std::endl;
    std::cout<<ub<<std::endl;
    std::cout<<lb<<std::endl;

    //将数据转换为qpOASES需要的形式
    int  size_H_qp=(Nc*Nu+1)*(Nc*Nu+1);
    qpOASES::real_t H_qp[size_H_qp];
    for(int i = 0;i<size_H_qp;i++)
    H_qp[i]=H(int(i/(Nc*Nu+1))  ,  (i%(Nc*Nu+1)));

    int  size_f_qp=Nc*Nu+1;
    qpOASES::real_t f_qp[size_f_qp];
    for(int i = 0;i<size_f_qp;i++)
    f_qp[i]=f(0,i);//这里f已经是转置了

    int  size_lb_qp=Nc*Nu+1;
    qpOASES::real_t lb_qp[size_lb_qp];
    for(int i = 0;i<size_lb_qp;i++)
    lb_qp[i]=lb(i,0);//优化变量的上下界

    qpOASES::real_t ub_qp[size_lb_qp];
    for(int i = 0;i<size_lb_qp;i++)
    ub_qp[i]=ub(i,0);//优化变量的上下界

    int  size_b_qua_qp=2*(Nc*Nu+1);
    qpOASES::real_t b_qua_qp[size_b_qua_qp];
    for(int i = 0;i<size_b_qua_qp;i++)
    b_qua_qp[i]=b_qua(i,0);

    int  size_A_qua_qp=2*(Nc*Nu+1)*(Nc*Nu+1);
    qpOASES::real_t A_qua_qp[size_A_qua_qp];
    for(int i = 0;i<size_A_qua_qp;i++)
    A_qua_qp[i]=A_qua( int(i/(Nc*Nu+1))  ,  (i%(Nc*Nu+1)) );
    int nV = (Nc*Nu+1);//变量个数
    int nC = 2*(Nc*Nu+1);//约束条件数量

    qpOASES::Options options;
    options.setToMPC();
	//options.enableFlippingBounds = BT_FALSE;
	// options.initialStatusBounds = qpOASES::ST_INACTIVE;
	// options.numRefinementSteps = 1;
	// options.enableCholeskyRefactorisation = 1;
    options.printLevel=qpOASES::PL_NONE;
    // qpOASES::QProblem example( nV,nC );
    qpOASES::QProblemB example( nV );
	example.setOptions( options );
    qpOASES::int_t nWSR = 100;
    // example.init( H_qp,f_qp,A_qua_qp,lb_qp,ub_qp,nullptr,b_qua_qp, nWSR );
    example.init( H_qp,f_qp,lb_qp,ub_qp, nWSR );
    qpOASES::real_t xOpt[nV];
    example.getPrimalSolution(xOpt);
    path_track_counter++;
    std::cout<<path_track_counter<<std::endl;
    std::pair<double,double> ans(xOpt[0]+Ur(0,0),xOpt[1]+Ur(1,0));
    std::cout<<"The control cmd is :  v "<<ans.first<<"  w "<<ans.second<<std::endl;
    return ans;
}



int main(int argc, char** argv)
{
    ros::init(argc,argv,"mpc_node");
    ros::NodeHandle n;
    MPC_Control control_handle(n,5,4,0.1,80); //轨迹已经初始化完成,初始状态已经生成，参考轨迹、输入已经完成
    std::pair<double,double> now_control_cmd;
    double thi=ros::Time::now().toSec();
    for(int i =0;i<control_handle.path_len;i++)
    {
        now_control_cmd=control_handle.MPC_Solve();//根据参考轨迹、状态信息，生成控制律
        control_handle.UpdateCarState(now_control_cmd.first,now_control_cmd.second);//根据控制律更新状态信息
        control_handle.his_pathx.push_back(control_handle.now_carstate(0,0));
        control_handle.his_pathy.push_back(control_handle.now_carstate(1,0));
    }
    double thie=ros::Time::now().toSec();
    std::cout<<"TIme is "<<thie - thi<<std::endl;
    ros::Rate rate(20);
    while(ros::ok())
    { 
        control_handle.ShowCar();
        rate.sleep();
    }
    return 1;
}
